from setuptools import find_packages, setup

setup(
    name="neurocrick",
    version="0.0.1",
    author="Faculty",
    author_email=["giulia.vecchi@faculty.ai","alexander.a@faculty.ai"],
    url="https://faculty.ai/",
    packages=find_packages(),
    # requires=['umap-learn']   # check this
)
