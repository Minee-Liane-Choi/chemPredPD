import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

import umap
from scipy.stats import gaussian_kde
from typing import Union, Optional


def density_color_scatter(
    x: Union[str, list, np.ndarray],
    y: Union[str, list, np.ndarray],
    data: Optional[pd.DataFrame] = None,
    s=50,
    edgecolor=None,
    cmap="inferno",
    ax=None,
):
    if ax is None:
        fig, ax = plt.subplots()

    if data is not None:
        ax.set_xlabel(x, fontsize=15)
        ax.set_ylabel(y, fontsize=15)

        x = data[x].values
        y = data[y].values

    # Calculate the point density
    xy = np.vstack([x, y])
    z = gaussian_kde(xy)(xy)

    # Sort the points by density, so that the densest points are plotted last
    idx = z.argsort()
    x, y, z = x[idx], y[idx], z[idx]

    ax.scatter(x, y, c=z, s=s, edgecolor=edgecolor, cmap=cmap)

    return ax


def make_corr_matrix_plot(
    dataframe,
    method="pearson",
    annot=True,
    fmt=".1f",
    cmap=sns.diverging_palette(230, 20, as_cmap=True),
    vmax=1.0,
    vmin=-1.0,
    figsize=(21, 18),
    mask_less_than=0.1,
    mask_upper_triangle=True,
):
    # Compute the correlation matrix
    corr = dataframe.corr(
        method=method
    )  # other methods: 'kendall', 'spearman'

    # Generate a mask for the upper triangle
    if mask_upper_triangle is True:
        mask = np.triu(np.ones_like(corr, dtype=bool))

        if mask_less_than is not None:
            mask2 = np.abs(corr) < mask_less_than

            mask = mask2 | mask
    elif mask_less_than is not None:
        mask = np.abs(corr) < mask_less_than
    else:
        mask = None
    # Set up the matplotlib figure
    f, ax = plt.subplots(figsize=figsize)

    # Draw the heatmap with the mask and correct aspect ratio
    sns.heatmap(
        corr,
        mask=mask,
        annot=annot,
        fmt=fmt,
        cmap=cmap,
        vmax=vmax,
        vmin=vmin,
        center=0,
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.5},
    )
    return f


def plot_multi_umap_init(
    dataframe, n_neighbors=10, metric="euclidean", min_dist=0.1
):

    fig, ax = plt.subplots(5, 5, figsize=(20, 20))
    ax = ax.ravel()
    for i in range(25):

        reducer = umap.UMAP(
            n_neighbors=n_neighbors, metric=metric, min_dist=min_dist
        )
        embedding = reducer.fit_transform(dataframe.values)

        sns.scatterplot(embedding[:, 0], embedding[:, 1], ax=ax[i])

    fig.suptitle(
        f"metric:{metric} - n_neighbors:{n_neighbors} - min_dist:{min_dist}",
        fontsize=20,
        y=0.9,
    )
    #     fig.tight_layout()
    return fig


def plot_pca_components_variability(
    pca_obj, variability: float, title=None, save=None
):

    sns.set_style("white")
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.set_facecolor("white")
    ax.spines["right"].set_visible(False)
    ax.spines["top"].set_visible(False)

    num_comps = len(pca_obj.explained_variance_ratio_)
    xi = np.arange(0, num_comps, step=1)
    y = np.cumsum(pca_obj.explained_variance_ratio_)

    plt.ylim(0.0, 1.1)
    plt.plot(xi, y, marker="o", linestyle="--", color="#9C9C9C")

    plt.xlabel("Number of Components")
    plt.ylabel("Cumulative variance (%)")
    if title is not None:
        plt.title(title, fontsize=14)

    comp_coord = xi[np.argmax(y > variability)]
    plt.axvline(x=comp_coord, color="#FA7268", linestyle="-")

    text = f"{comp_coord+1} components\n>{variability*100}% var"

    plt.text(comp_coord + 0.5, 0.5, text, color="#FA7268", fontsize=12)

    if save is not None:
        fig.savefig(save, dpi=plt.gcf().dpi, bbox_inches="tight")

    plt.show()


def plot_points_distance(
    ax, x, y, label=None, marker_color="#3E3E3E", linecolor="#B5B5B5"
):

    ax.plot(x, y, "o", c=marker_color, label=label)
    # adding vertical lines to measure error size (distance from origin line)
    ax.vlines(x, 0, y, colors=linecolor)

    ax.legend()
    ax.axhline(0, c="black")
    return ax
