import string
from IPython.display import display_html


def display_side_by_side(*args):
    html_str = ""
    for df in args:
        html_str += df.to_html()
    display_html(
        html_str.replace("table", 'table style="display:inline"'), raw=True
    )


def filter_out_by_keywords(columns, keywords):
    if isinstance(keywords, str):
        return [x for x in columns if keywords not in x]
    elif isinstance(keywords, (tuple, list)):
        return [x for x in columns if not any([y in x for y in keywords])]


def select_by_keywords(columns, keywords):
    if isinstance(keywords, str):
        return [x for x in columns if keywords in x]
    elif isinstance(keywords, (tuple, list)):
        return [x for x in columns if any([y in x for y in keywords])]


def col2num(col):
    num = 0
    for c in col:
        if c in string.ascii_letters:
            num = num * 26 + (ord(c.upper()) - ord("A")) + 1
    return num - 1


def colnum2excelcol(n):
    n = n + 1
    string = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        string = chr(65 + remainder) + string
    return string


def colname2excelcol(col, column_list):
    return colnum2excelcol(column_list.index(col))


def get_columns(col, columns):
    if isinstance(col, str):
        return columns[col2num(col)]
    else:  # assuming is iterable of strings
        return [columns[col2num(each)] for each in col]


def get_column_range(columns, col_start=None, col_end=None):
    if col_start is None and col_end is None:
        return columns
    elif col_start is None:
        return columns[: col2num(col_end) + 1]
    elif col_end is None:
        return columns[col2num(col_start) :]
    else:
        return columns[col2num(col_start) : col2num(col_end) + 1]


def get_df_column_range(dataframe, col_start=None, col_end=None):
    if col_start is None and col_end is None:
        return dataframe
    elif col_start is None:
        return dataframe.iloc[:, : col2num(col_end) + 1]
    elif col_end is None:
        return dataframe.iloc[:, col2num(col_start) :]
    else:
        return dataframe.iloc[:, col2num(col_start) : col2num(col_end) + 1]


def get_df_columns(col, dataframe):
    return dataframe[get_columns(col, columns=dataframe.columns)]
