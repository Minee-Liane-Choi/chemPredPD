from scipy.ndimage import gaussian_filter
from skimage import img_as_float
from skimage.morphology import reconstruction
from skimage.util import img_as_ubyte
import numpy as np
import cv2

red_ch = 3  # red - mito
green_ch = 4  # green - lyso
blue_ch = 1  # blue - nucleus

def create_image_zstack(image_id, metadata, only_equalize=False):
    # image_group is group of images with one fixed ID
    # There are multiple zs and multiple channels in the group
    zstack = []
    for i, stack_z in enumerate(sorted(metadata.z.unique())):
        nobi_image = get_image(
            image_id,
            stack_z,
            metadata,
            only_equalize=only_equalize,
        )
        zstack.append(nobi_image)
    # This image_zstack is an image 'sequence'
    image_zstack = np.stack(zstack, axis=2)
    return image_zstack


def create_3d_tiles(
    image_zstack,
    num_x_tiles=4,
    num_y_tiles=4,
    #     mean_threshold=2.5, # Thresholds could do with tuning
    #     var_threshold=20,
):
    tiles = _split_2d(image_zstack, (num_x_tiles, num_y_tiles))

    # tiles_filtered = []
    # for tile in tiles:
    #     # Array of z-means, z_vars for each tile
    #     tile_zmeans = np.mean(
    #         tile.swapaxes(0, 2).swapaxes(1, 2), axis=(1, 2, 3)
    #     )
    #     tile_zvars = np.var(
    # tile.swapaxes(0, 2).swapaxes(1, 2), axis=(1, 2, 3)
    # )
    #     # Only wish to return tiles above a threshold
    #     # We keep the tile if ANY of its zstack elements exceeds threshold
    #     if np.any(tile_zmeans > mean_threshold) and np.any(
    #         tile_zvars > var_threshold
    #     ):
    #         tiles_filtered.append(tile)
    # return tiles_filtered
    return tiles
    
def get_image(
    image_id,
    z_stack,
    metadata,
    only_equalize=False,
    black_th_red=2,
    black_th_green=2,
    black_th_blue=2,
):

    img_red, img_green, img_blue = get_image_channels(
        image_id, z_stack, metadata
    )

    if only_equalize:
        img_red = equalize_channel(img_red, black_th=black_th_red)
        img_green = equalize_channel(img_green, black_th=black_th_green)
        img_blue = equalize_channel(img_blue, black_th=black_th_blue)
    else:
        img_red = full_process_channel(img_red, black_th=black_th_red)
        img_green = full_process_channel(img_green, black_th=black_th_green)
        img_blue = full_process_channel(img_blue, black_th=black_th_blue)

    return cv2.merge([img_red, img_green, img_blue])


def _split_2d(array, splits):
    x, y = splits
    return np.split(np.concatenate(np.split(array, y, axis=1)), x * y)


def equalize_channel(channel, black_th=2):

    channel = cv2.equalizeHist(black_threshold(channel, th=black_th))

    return channel


def black_threshold(image, th=2):
    mask = 255 * (image >= th).astype("uint8")
    result = cv2.bitwise_and(image, mask)
    return result


def simple_normalise_image(image):
    if image.max() != 0:
        image = (255 * ((image - image.min()) / (image.max()))).astype(
            np.uint8
        )
    return image


def full_process_channel(channel, h=0.4, sigma=1, black_th=2):

    channel = simple_normalise_image(channel)

    image = img_as_float(channel)
    image = gaussian_filter(image, sigma)

    mask = image
    seed = image - h

    dilated = reconstruction(seed, mask, method="dilation")
    hdome = image - dilated

    hdome = equalize_channel(img_as_ubyte(hdome), black_th=black_th)

    return hdome


def get_image_channels(
    image_id,
    z_stack,
    metadata,
    red_ch=red_ch,
    green_ch=green_ch,
    blue_ch=blue_ch,
):

    mask = (metadata.image_ID == image_id) & (metadata.z == z_stack)
    channel_paths_dict = (
        metadata[mask][["channel", "filepath"]]
        .set_index("channel")
        .to_dict()["filepath"]
    )

    img_red = cv2.imread(channel_paths_dict[red_ch], cv2.IMREAD_GRAYSCALE)
    img_green = cv2.imread(channel_paths_dict[green_ch], cv2.IMREAD_GRAYSCALE)
    img_blue = cv2.imread(channel_paths_dict[blue_ch], cv2.IMREAD_GRAYSCALE)

    return img_red, img_green, img_blue


