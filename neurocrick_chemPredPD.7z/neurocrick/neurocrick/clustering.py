from typing import Optional, Union
import abc
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture
from sklearn.pipeline import Pipeline
from umap import UMAP


class ParentClusterModel(abc.ABC):
    def __init__(self, feature_df: pd.DataFrame):

        self.feature_columns = feature_df.columns
        self.index_patients = feature_df.index
        self.input_data = feature_df

    @property
    @abc.abstractmethod
    def pipe(self):
        """Children must define a pipe"""

    @property
    def steps(self):
        return list(self.pipe.named_steps.keys())

    def run_clustering(
        self,
        fit_pipe=None,
        return_as_dataframe: bool = False,
        cluster_column_name="cluster",
    ) -> Union[np.ndarray, pd.DataFrame]:

        if fit_pipe is None:
            fit_pipe = self.pipe

        results = fit_pipe.predict_proba(self.input_data.values)

        if return_as_dataframe:
            results_df = pd.DataFrame(results, index=self.index_patients)
            results_df[cluster_column_name] = results_df.apply(
                np.argmax, axis=1
            )
            return results_df
        else:
            return results

    def get_pipeline_step(
        self,
        step: str,
        fit_pipe=None,
        data: Optional[pd.DataFrame] = None,
        return_as_dataframe: bool = False,
        use_feature_names: bool = False,
        columns: Optional[list] = None,
    ) -> Union[np.ndarray, pd.DataFrame]:

        if data is None:
            data = self.input_data

        step_index = self.steps.index(step)

        if fit_pipe is None:
            fit_pipe = self.pipe

        res = Pipeline(fit_pipe.steps[: step_index + 1]).transform(data.values)

        if return_as_dataframe:
            if use_feature_names:
                return _feature_array_to_dataframe(
                    res,
                    indexes=self.index_patients,
                    columns=self.feature_columns,
                )
            else:
                return _feature_array_to_dataframe(
                    res, indexes=self.index_patients, columns=columns,
                )
        else:
            return res


class ClusterDATModel(ParentClusterModel):
    def __init__(
        self,
        feature_df: pd.DataFrame,
        umap_random_state: int = 42,
        gmm_random_state: int = 42,
        gmm_components: int = 2,
        umap_components: int = 2,
    ):

        self.category_name = "DAT"

        super().__init__(feature_df=feature_df)

        umap = UMAP(
            random_state=umap_random_state,
            n_components=umap_components,
            n_neighbors=10,
            metric="cosine",
            min_dist=0.05,
        )

        self._pipe = Pipeline(
            [
                ("umap", umap),
                (
                    "GMM_clusters",
                    GaussianMixture(
                        n_components=gmm_components,
                        random_state=gmm_random_state,
                    ),
                ),
            ]
        )

    @property
    def pipe(self):
        # return self._pipe.fit(self.input_data)
        return self._pipe.fit(self.input_data.values)

    def get_umap_axes(
        self, fit_pipe=None, return_as_dataframe: bool = False
    ) -> Union[np.ndarray, pd.DataFrame]:

        return self.get_pipeline_step(
            "umap",
            fit_pipe=fit_pipe,
            return_as_dataframe=return_as_dataframe,
            columns=[
                f"umap0_{self.category_name}",
                f"umap1_{self.category_name}",
            ],
        )

    def get_umap_and_clusters(self, fit_pipe=None):
        umap_df = self.get_umap_axes(
            fit_pipe=fit_pipe, return_as_dataframe=True
        )
        clus_df = self.run_clustering(
            fit_pipe=fit_pipe,
            return_as_dataframe=True,
            cluster_column_name=f"cluster_{self.category_name}",
        )
        return umap_df.join(clus_df)


class ClusterLOGModel(ParentClusterModel):
    def __init__(
        self,
        feature_df: pd.DataFrame,
        pca_random_state: int = 0,
        pca_components: int = 7,
        umap_random_state: int = 42,
        gmm_random_state: int = 42,
        gmm_components: int = 2,
        umap_components: int = 2,
    ):

        self.category_name = "LOG"

        super().__init__(feature_df=feature_df)

        umap = UMAP(
            random_state=umap_random_state,
            n_components=umap_components,
            n_neighbors=10,
            metric="cosine",
            min_dist=0.05,
        )

        self._pipe = Pipeline(
            [
                (
                    "PCA",
                    PCA(
                        random_state=pca_random_state,
                        n_components=pca_components,
                    ),
                ),
                ("umap", umap),
                (
                    "GMM_clusters",
                    GaussianMixture(
                        n_components=gmm_components,
                        random_state=gmm_random_state,
                    ),
                ),
            ]
        )

    @property
    def pipe(self):
        # return self._pipe.fit(self.input_data)
        return self._pipe.fit(self.input_data.values)

    def get_umap_axes(
        self, fit_pipe=None, return_as_dataframe: bool = False
    ) -> Union[np.ndarray, pd.DataFrame]:

        return self.get_pipeline_step(
            "umap",
            fit_pipe=fit_pipe,
            return_as_dataframe=return_as_dataframe,
            columns=[
                f"umap0_{self.category_name}",
                f"umap1_{self.category_name}",
            ],
        )

    def get_umap_and_clusters(self, fit_pipe=None):
        umap_df = self.get_umap_axes(
            fit_pipe=fit_pipe, return_as_dataframe=True
        )
        clus_df = self.run_clustering(
            fit_pipe=fit_pipe,
            return_as_dataframe=True,
            cluster_column_name=f"cluster_{self.category_name}",
        )
        return umap_df.join(clus_df)


def _feature_array_to_dataframe(
    feature_array: np.ndarray, indexes: list, columns: Optional[list] = None
) -> pd.DataFrame:

    if columns is not None:
        return pd.DataFrame(feature_array, index=indexes, columns=columns,)
    else:
        return pd.DataFrame(feature_array, index=indexes)
