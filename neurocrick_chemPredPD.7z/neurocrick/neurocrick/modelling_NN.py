import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)
from typing import Optional, Callable
from tensorflow.keras.layers import Input, Dense, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.utils import to_categorical
from tensorflow.random import set_seed

set_seed(42)


def plate_train_test_split(
    data: pd.DataFrame,
    training_plates: tuple,
    feature_columns: list,
    label_column: str,
):

    data_train = data[data.PlateID.isin(training_plates)].sample(
        frac=1, random_state=0
    )
    data_test = data[~data.PlateID.isin(training_plates)].sample(
        frac=1, random_state=0
    )

    return (
        data_train[feature_columns].values,
        data_test[feature_columns].values,
        data_train[label_column].values,
        data_test[label_column].values,
    )


def train_model(
    X_train,
    y_train,
    X_test,
    y_test,
    model: Optional[Callable] = None,
    num_dense=40,
    save=False,
    model_name=None,
    batch_size=64,
    epochs=200,
    dropout_rate=0.2,
    patience=40,
    verbose=0,
):
    if len(np.shape(y_train)) != len(np.unique(y_train)):
        y_train = to_categorical(y_train)

    if len(np.shape(y_test)) != len(np.unique(y_test)):
        y_test = to_categorical(y_test)

    early_stops = tf.keras.callbacks.EarlyStopping(
        monitor="val_loss",
        min_delta=0,
        patience=patience,
        verbose=verbose,
        mode="auto",
        restore_best_weights=True,
    )

    callbacks = [early_stops]
    
    if save is True:
        if model_name is None:
            model_name = 'model'
        else:
            model_name = model_name.replace(".hdf5", "")
        
        checkpoint = ModelCheckpoint(
            str(model_name) + ".hdf5",
            monitor="val_loss",
            verbose=verbose,
            save_best_only=True,
            mode="auto",
            save_freq="epoch",
        )
        callbacks.append(checkpoint)
        
    if model is None:
        mod = dense3_net(
            input_shape=X_train.shape[1],
            output_shape=y_train.shape[1],
            num_dense=num_dense,
            dropout_rate=dropout_rate,
        )
    else:
        mod = model(
            input_shape=X_train.shape[1], output_shape=y_train.shape[1],
        )

    mod.compile(
        loss="categorical_crossentropy",
        metrics=["accuracy"],
        optimizer="adam",
    )

    history = mod.fit(
        X_train,
        y_train,
        validation_data=(X_test, y_test),
        batch_size=batch_size,
        epochs=epochs,
        callbacks=callbacks,
        verbose=verbose,
    )
    return mod, history


def dense3_net(input_shape, output_shape, num_dense=40, dropout_rate=0.2):

    input_t = Input(shape=(input_shape,))

    x = Dense(num_dense, activation="relu")(input_t)
    x = Dropout(dropout_rate)(x)

    x = Dense(num_dense, activation="relu")(x)
    x = Dropout(dropout_rate)(x)

    x = Dense(num_dense, activation="relu")(x)
    x = Dropout(dropout_rate)(x)

    output = Dense(output_shape, activation="softmax")(x)

    model = Model(inputs=input_t, outputs=output)
    return model


def plot_training_progress(history, title=None, save=None, figsize=(14, 7)):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

    ax1.plot(history.history["loss"], label="Training")
    ax1.plot(history.history["val_loss"], label="Validation")
    ax1.legend(frameon=False)
    ax1.set_title("Loss")
    ax1.set_ylabel("Loss")
    ax1.set_xlabel("Epochs")

    ax2.plot(history.history["accuracy"], label="Training")
    ax2.plot(history.history["val_accuracy"], label="Validation")
    ax2.legend(frameon=False)
    ax2.set_title("Accuracy")
    ax2.set_ylabel("Accuracy")
    ax2.set_xlabel("Epochs")

    if title is not None:
        fig.suptitle(title)

    if save is not None:
        fig.savefig(save, bbox_inches="tight")
    fig.show()


def plot_roc(y_true, y_pred_scores, title=None, save=None, return_auc=True):

    fpr, tpr, thresholds = roc_curve(y_true, y_pred_scores[:, 1])
    auc_score = roc_auc_score(y_true, y_pred_scores[:, 1])

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(
        fpr,
        tpr,
        color="darkorange",
        lw=2,
        label="ROC curve (area = %0.2f)" % auc_score,
    )
    ax.plot([0, 1], [0, 1], color="navy", lw=2, linestyle="--")
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")

    if title is not None:
        ax.set_title(title)

    ax.legend(loc="lower right", frameon=False)

    fig.suptitle("ROC Curve", fontsize=15, y=1.01)

    if save is not None:
        fig.savefig(save, bbox_inches="tight")
    fig.show()
    if return_auc:
        return auc_score


def plot_confusion_matrix(
    y_true, y_pred_scores, display_labels=None, save=None, title=None
):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 7))

    ax1.set_title("Count")
    scal_matrix = confusion_matrix(y_true, y_pred_scores.argmax(axis=1))

    scal_matrix_norm = confusion_matrix(
        y_true, y_pred_scores.argmax(axis=1), normalize="true"
    )

    ConfusionMatrixDisplay(
        confusion_matrix=scal_matrix, display_labels=display_labels
    ).plot(cmap="Blues", ax=ax1)

    ax1.set_ylabel(ax1.get_ylabel(), fontsize=15)
    ax1.set_xlabel(ax1.get_xlabel(), fontsize=15, labelpad=10)
    fig.axes[-1].set_visible(False)

    ax2.set_title("Fraction")
    ConfusionMatrixDisplay(
        confusion_matrix=scal_matrix_norm, display_labels=display_labels,
    ).plot(cmap="Blues", ax=ax2)

    ax2.set_ylabel(ax2.get_ylabel(), fontsize=15)
    ax2.set_xlabel(ax2.get_xlabel(), fontsize=15, labelpad=10)
    fig.axes[-1].set_visible(False)

    fig.tight_layout()
    suptitle = "CONFUSION MATRIX"
    if title is not None:
        suptitle += f"\n{title}"
    fig.suptitle(suptitle, y=1.01)

    if save is not None:
        fig.savefig(save, bbox_inches="tight")
    plt.show()
