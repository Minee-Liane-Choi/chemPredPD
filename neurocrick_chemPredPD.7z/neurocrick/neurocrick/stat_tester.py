from typing import Callable, Optional, Tuple
import numpy as np
import functools
from numpy.core.numeric import asanyarray


def _permutation_sampler(labels):
    while True:
        yield labels[np.argsort(np.random.random(size=labels.shape[0]))]


def mean_diff(x, labels):
    return x[labels == 1].mean(axis=0) - x[labels == 0].mean(axis=0)


def median_diff(x, labels):
    return np.median(x[labels == 1], axis=0) - np.median(
        x[labels == 0], axis=0
    )


def _map_statistic_onto_samples(
    build_sampler,
    statistic: Callable[[np.ndarray], np.ndarray],
    n_samples: int,
) -> np.ndarray:
    sampler = build_sampler()
    sample = next(sampler)
    res = asanyarray(statistic(sample))
    buff = np.zeros((n_samples,) + res.shape)
    buff[0] = res
    for i, sample in enumerate(sampler, start=1):
        if i >= n_samples:
            break
        buff[i] = asanyarray(statistic(sample))
    return buff


def permutation_test(
    data: np.ndarray, labels: np.ndarray, n_samples: int, *, statistic=None
) -> np.ndarray:
    try:
        data, statistic = validate(
            data, statistic, default_statistic=lambda data, labels: labels
        )
    except EmptyDataError:
        return data

    labels = asanyarray(labels)
    if data.shape[0] != labels.shape[0]:
        raise ValueError(
            "Shape mismatch: first dimension of data and labels should be the "
            "same size."
        )
    statistic = functools.partial(statistic, data)
    build_sampler = functools.partial(_permutation_sampler, labels)
    return _map_statistic_onto_samples(build_sampler, statistic, n_samples)


class EmptyDataError(Exception):
    pass


def validate(
    data: np.ndarray,
    statistic: Optional[Callable[[np.ndarray], np.ndarray]],
    default_statistic=lambda x: x,
) -> Tuple[np.ndarray, Callable[[np.ndarray], np.ndarray]]:
    data = asanyarray(data)
    if data.ndim == 0:
        raise ValueError("Parameter 'data' cannot be a scalar")
    elif data.size == 0:
        raise EmptyDataError
    statistic = statistic or default_statistic
    return data, statistic
